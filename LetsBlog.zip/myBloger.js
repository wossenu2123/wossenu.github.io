let posts = [];
let currentUser = prompt("Enter your name to continue:")

function addPost() {
    const title = document.getElementById('postTitle').value;
    const content = document.getElementById('postContent').value;
    const author = currentUser;

    if (title && content && author) {
        posts.push({ title, content, author, likes: 0, dislikes: 0, comments: [] });
        document.getElementById('postTitle').value = '';
        document.getElementById('postContent').value = '';
        console.log(posts); // Check if the contents of the posts array
        savePosts();
        displayPosts();
    } else {
        alert('Please fill in the title, content, and author fields.');
    }
}

function displayPosts() {
    const blogPostsDiv = document.getElementById('blogPosts');
    blogPostsDiv.innerHTML = '';

    posts.forEach((post, index) => {
        const postDiv = document.createElement('div');
        postDiv.classList.add('post');

        const contentWithNewLines = post.content.replace(/\n/g,'<br>'); // Replace newline characters with <br>
        
        postDiv.innerHTML = `
            <h2>${post.title}</h2>
            <p>${contentWithNewLines}</p>
            <p>Author: ${post.author}</p>
            <button onclick="likePost(${index})">Like(${post.likes})</button>
            <button onclik="dislikePost(${index})">Dislike(${post.dislikes})</button>;`
   

   
        // Check if the current user is the author
        const deleteButtonHTML = (currentUser === post.author) ? `<button onclick="deletePost(${index})">Delete</button>` : '';

        postDiv.innerHTML = `
            <h2>${post.title}</h2>
            <p>${post.content}</p>
            <small>ፀሀፊ: ${post.author}</small> 
             <!-- Show the author here -->
           <button onclick="likePost(${index})">ከወደዱት</button>
            <span id="likeCount${index}">${post.likes} </span>
           <button onclick="dislikePost(${index})">ካልወደዱት</button>
            <span id="dislikeCount${index}">${post.dislikes} </span>
            <div class="comments">
                <h3>በፅሁፉ ላይ የተነሱ  ሃሳቦች</h3>
                <div id="commentSection${index}"></div>
                <input type="text" id="commentInput${index}" placeholder="የርስዎን ሃሳብ ይጨምሩ">
                <button onclick="addComment(${index})">የርስዎ ሃሳብ</button>
            </div>
            ${deleteButtonHTML} <!-- Only show delete if the user is the author -->
            `;

        blogPostsDiv.appendChild(postDiv);
        displayComments(index);
    });
}

function likePost(index) {
    posts[index].likes += 1;
    savePosts();
    displayPosts();
}

function dislikePost(index) {
    posts[index].dislikes += 1;
    savePosts();
    displayPosts();
}

function addComment(index) {
    const commentInput = document.getElementById(`commentInput${index}`);
    const commentText = commentInput.value;

    if (commentText) {
        posts[index].comments.push(commentText);
        commentInput.value = '';
        displayComments(index);
        savePosts();
    } else {
        alert('Please enter a comment.');
    }
}

function displayComments(index) {
    const commentSection = document.getElementById(`commentSection${index}`);
    commentSection.innerHTML = '';

    if(posts[index] && Array.isArray(posts[index].comments)) 
    {

    posts[index].comments.forEach(comment => {
        const commentDiv = document.createElement('div');
        commentDiv.classList.add('comment');
        commentDiv.innerText = comment;
        commentSection.appendChild(commentDiv);
          });
    }
}

function deletePost(index) {
    if (currentUser === posts[index].author) {
        posts.splice(index, 1);
        savePosts();
        displayPosts();
    } else {
        alert("You can only delete your own posts.");
    }
}

function savePosts() {
    localStorage.setItem('blogPosts', JSON.stringify(posts));
}

function loadPosts() {
    const storedPosts = localStorage.getItem('blogPosts');
    if (storedPosts) {
     // parse the stored data and filter out posts without an author

    const parsedPosts = JSON.parse(storedPosts);

    if (Array.isArray(parsedPosts)) {
        // Filter out posts that don't have an author
        posts = parsedPosts.filter(post => post.author); // Keep only posts with an author
          
        
    } else {
        
        posts = []; // If not an array, initialize an empty array
    } 
    displayPosts(); // Update the UI to show the filtered posts
} else {
    posts = []; // If nothing is stored, initialize an empty array
}

displayPosts(); // Display the filtered posts 
saveFilteredPosts(); // save the filtered posts back to local storage
}

function saveFilteredPosts() {
    localStorage.setItem('posts', JSON.stringify(posts)); // Update local storage
}

window.onload = function() {
    loadPosts(); // Load posts from local storage
};


